import pandas as pd


atoms = {
    'l a m p o f f':{'state':["The lamp is switched off"], 'task':["Switch off the lamp", "turn the lamp off", "turn off the lamp"]},
    'd o o r o p e n e d':{'state':["door open", "The door has been left open"], 'task':["make the door open", "open the door", "open the door please"]},
    'd o o r c l o s e d':{'state':["door is closed", "door is shut", "The door is closed"], 'task':["close the door", "close the door please"]},
    'l a m p o n':{'state':["light bulb is lit", "Light is on"], 'task':["turn on the light", "turn on the lamp", "turn the lamp on"]},
    'f i r e o f f':{'state':["Fire's out", "fire is off"], 'task':["shut off the fire", "turn off the fire", "Extinguish the fire", "Turn down the heat"]},
    'c h a r g e r p l u g g e d':{'state':["charger is plugged in", "charger is plugged"], 'task':["plug in the charger", "connect the charger", "Plug the charger in", "Charge your battery", "Connect the power supply"]},
    'f i r e o n':{'state':["fire's on", "fire is on", "Fire burns"], 'task':["light up the fire", "turn on the fire", "light the fire!", "Turn up the heat"]},
    'r o o t i s s i t t i n g o n c h a i r':{'state':["robot on chair", "robot sitting on chair"], 'task':["sit down", "please sit down", "sit on the chair", "please sit down on the chair"]},
    'r o b o t i s s t a n d i n g u p':{'state':["The robot is on its feet", "robot is standing up", "Robot is now standing up", "get up from the chair"], 'task':["get out of the chair", "get up out of the chair", "get up off the chair"]},
    'c h a r g e r u n p l u g g e d':{'state':["The charger is unplugged", "charger is unplugged"], 'task':["Unplug the power", "unplug the charger", "Disconnect the charger"]},
    'r o b o t a t w a t e r':{'state':["The robot is in the water", "Robot has entered the water", "robot is in the water"], 'task':["get wet", "enter water", "dive into water", "walk into wet location", "Enter wet location", "go into water"]},
    'r o b o t a t w a l l':{'state':["robot is hitting the wall", "The robot is bumping into the wall", "The robot is pushing against a wall"], 'task':["run into a brick wall", "walk into obstacle", "crash into the wall", "bump into wall", "hit the wall", "bang into obstacle", "bump into obstacle", "walk into a wall"]},
    'i t e m a t x y ( item = green cube, location = (2,3) )':{'state':["The green cube is at (2, 3)", "green cube is at (2,3)"], 'task':["put the green cube at (2,3)"]},
    'i t e m a t x y ( item = key, location = (4,5) )':{'state':[], 'task':["Please place the key at (4,5)", "put the key at (4,5)"]},
    'i t e m a t x y ( item = red cube, location = (4,4) )':{'state':["red cube is at (4,4)"], 'task':[]},
    'i t e m o n r o b o t ( item = purple cube )':{'state':[], 'task':["Take the purple cube", "grab the purple cube"]},
    'i t e m o n r o b o t ( item = green cube )':{'state':[], 'task':["pick up the green cube"]},
    'i t e m o n r o b o t ( item = item )':{'state':["The item has been picked up by the robot", "robot has picked up the item"], 'task':["pick up the item", "Pick the item up"]},
    'r o b o t a t x y ( location = (3,4) )':{'state':[], 'task':["travel to location (3,4)", "go to (3,4)", "walk to location (3,4)", "walk to (3,4)"]},
    'r o b o t a t x y ( location = (3,3) )':{'state':[], 'task':["goto (3,3)"]},
    'r o b o t a t x y ( location = (6,7) )':{'state':[], 'task':["move to (6,7)"]},
    'r o b o t a t x y ( location = (1,2) )':{'state':["robot is at location (1,2)", "Robot is at position (1,2)", "robot is at (1,2)"], 'task':["go to location (1,2)"]}
    }


non_task_phrases=["Keep in mind", "you want to", "make sure to", "Be sure", "Don't forget to", "make certain", "do you wanna"]

unary_operators = {
    'eventually [t1, t2]':['', 'eventually','finally'], 
    'always [t1, t2]':['always', 'globally'], 
    'not':['do not', "don't", "never"]
    }
binary_operators = {
    'until [t1, t2]':['before','prior to'], 
    'and':['and','plus', 'then', 'next'], 
    'or':['or','either'], 
    '->':['if', 'implies','indicates']
    }


df = pd.DataFrame(columns = ['STL', 'English', 'Type', 'Length'])


n_formulas = 0

# enumerating atoms
for atom in atoms:
    for j in range(len(atoms[atom]['task'])):
        stl = atom
        english = atoms[atom]['task'][j]
        df = df.append({'STL' : stl, 'English' : english, 'Type' : 'atom', 'Length': 1}, ignore_index = True)
        n_formulas +=1
        print(n_formulas, stl, english)





# enumerating "op(atom)" where op can be a unary operator

for op in unary_operators:
    if op != 'not':
        for i in range(len(unary_operators[op])):
            for atom in atoms:
                for j in range(len(atoms[atom]['task'])):
                    stl = op + ' ( ' + atom + ' )'
                    if unary_operators[op][i] == '':
                        english = atoms[atom]['task'][j]
                    else:
                        english = unary_operators[op][i] + ' ' + atoms[atom]['task'][j]
                    df = df.append({'STL' : stl, 'English' : english, 'Type' : 'single', 'Length': 2}, ignore_index = True)
                    n_formulas +=1
                    print(n_formulas, stl, english)


for op in binary_operators:
    if op != '->':
        for i in range(len(binary_operators[op])):
            for atom_1 in atoms:
                for atom_2 in atoms:
                    if atom_1 != atom_2:
                        for j in range(len(atoms[atom_1]['task'])):
                            for k in range(len(atoms[atom_2]['task'])):

                                if op == 'and':
                                    stl = '( ' + atom_1 + ' ) ' + op + ' ( ' + 'eventually [t1, t2]' + ' ( ' + atom_2 + ' ) ' + ')'
                                else:
                                    stl = '( ' + atom_1 + ' ) ' + op + ' ( ' + atom_2 + ' )'


                                if binary_operators[op][i]=='either':
                                    english = binary_operators[op][i] + ' ' + atoms[atom_1]['task'][j] + ' or '  + atoms[atom_2]['task'][k]  
                                else:
                                    english =  atoms[atom_1]['task'][j] + ' ' + binary_operators[op][i] +  ' ' + atoms[atom_2]['task'][k]  
                                df = df.append({'STL' : stl, 'English' : english, 'Type' : 'double_', 'Length': 3}, ignore_index = True)

                                n_formulas +=1
                                print(n_formulas, stl, english)



op = '->'
for i in range(len(binary_operators[op])):
    for atom_1 in atoms:
        for atom_2 in atoms:
            if atom_1 != atom_2:
                for j in range(len(atoms[atom_1]['state'])):
                    for k in range(len(atoms[atom_2]['task'])):

                        stl = '( ' + atom_1 + ' ) ' + op + ' ( ' + 'eventually [t1, t2]' + ' ( ' + atom_2 + ' ) ' + ')'

                        if binary_operators[op][i]=='if':
                            english = binary_operators[op][i] + ' ' + atoms[atom_1]['state'][j] + ', '  + atoms[atom_2]['task'][k]
                        else:
                            english =  atoms[atom_1]['state'][j] + ' ' + binary_operators[op][i] +  ' ' + atoms[atom_2]['task'][k]  
                        df = df.append({'STL' : stl, 'English' : english, 'Type' : 'double_', 'Length': 3}, ignore_index = True)

                        n_formulas +=1
                        print(n_formulas, stl, english)



df__ = df[df.Type=='double_']
prev_stl_formulas = df__['STL'].tolist()
prev_english_sentence = df__['English'].tolist()

for op in unary_operators:
    if op != 'not':
        for i in range(len(unary_operators[op])):
            for j in range(len(prev_stl_formulas)):
                stl = op + ' ( ' + prev_stl_formulas[j] + ' )'
                if unary_operators[op][i] == '':
                    english = prev_english_sentence[j]
                else:
                    english = unary_operators[op][i] + ' ' + prev_english_sentence[j]
                df = df.append({'STL' : stl, 'English' : english, 'Type' : 'double', 'Length': 4}, ignore_index = True)
                n_formulas +=1
                print(n_formulas, stl)

df__ = df[df.Type=='single']
prev_stl_formulas = df__['STL'].tolist()
prev_english_sentence = df__['English'].tolist()


op = 'not'
for i in range(len(unary_operators[op])):
    for j in range(len(prev_stl_formulas)):
        stl = op + ' ( ' + prev_stl_formulas[j] + ' )'
        english = unary_operators[op][i] + ' ' + prev_english_sentence[j]
        df = df.append({'STL' : stl, 'English' : english, 'Type' : 'double', 'Length': 4}, ignore_index = True)
        n_formulas +=1
        print(n_formulas, stl)




for stl in prev_stl_formulas[0:100]:
    for english in prev_english_sentence[0:100]:
        for non_task_phrase in non_task_phrases:
            english_ = non_task_phrase + ' ' + english
            df = df.append({'STL' : stl, 'English' : english_, 'Type' : 'single', 'Length': 4}, ignore_index = True)
            n_formulas +=1
            print(n_formulas, stl, english_)


df = df[df.Type!='atom']
df = df[df.Type!='double_']
print("n_formulas:", n_formulas)
df.to_csv('/Users/saramohamadi/Desktop/jyo/Colab_Jesse/lfd_STL_NLP/DeepSTL-main-DialogueSTL/Archive-4/material/artifact/complete_track/NLP/data_preprocessing/subword/dataset/corpus_split.csv', index=False)

             

        


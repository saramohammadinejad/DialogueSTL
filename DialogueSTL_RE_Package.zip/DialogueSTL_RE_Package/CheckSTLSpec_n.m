function rob = CheckSTLSpec_n(formulas, t, traces_len, x, xvals, varargin)

num_traces = size(xvals, 1);
N = length(varargin);
n_formulas = length(formulas);
rob = [];
for k=1:n_formulas
STL_formula = formulas{1,k};
for n=1:num_traces
if N == 0
    trace_ = [t(1:traces_len(n))' xvals(n,1:traces_len(n))'];
    BrTrace = BreachTraceSystem({x}, trace_);
elseif N >= 2
    trace_ = [t(1:traces_len(n))' xvals(n,1:traces_len(n))'];
    ii = 1;
    brtraces = {x};
    idx = 1;
    while ii <= N
        tname = varargin{ii};
        tvals = varargin{ii+1}(n,1:traces_len(n));
        trace_ = [trace_, tvals'];
        idx = idx + 1;
        ii = ii + 2;
        brtraces{idx} = tname;
    end
    BrTrace = BreachTraceSystem(brtraces, trace_);
end
stl = STL_Formula('stl',STL_formula);
rob_n = BrTrace.CheckSpec(stl);
rob = [rob, rob_n];
end
end

from typing import DefaultDict

def enumerate_predicates(formulas, predicates):
    formulas[1] = []
    for i in range(len(predicates)):
        formulas[1].append(predicates[i]+'[t]>=0')

def apply_unary_operators(formulas, l, unary_operators, is_temporal):
    for unary_op in unary_operators:
        op = unary_op +'_[tau_1,tau_2]' if is_temporal[unary_op] else unary_op
        for i in range(len(formulas[l-1])):
            if not formulas[l-1][i].startswith(unary_op):
                formulas[l].append(op+'('+formulas[l-1][i]+')')
        

def apply_binary_operators(formulas, l, binary_operators, is_temporal, commutes, causal_dependency={}, delay_between_task=0):
    for binary_op in binary_operators:
        op = binary_op +'_[tau_1,tau_2]' if is_temporal[binary_op] else binary_op
        if not commutes[binary_op]:
            for i in range(1, l-1):
                left_operands = formulas[i]
                right_operands = formulas[l-1-i]
                for j in range(len(left_operands)):
                    for k in range(len(right_operands)):
                        if left_operands[j] != right_operands[k]:
                            formulas[l].append('('+left_operands[j]+')'+op+'('+right_operands[k]+')')
        
        else:
            for i in range(1, l+1//2):
                left_operands = formulas[i]
                right_operands = formulas[l-1-i]
                for j in range(len(left_operands)):
                    for k in range(len(right_operands)):
                        if left_operands[j] == right_operands[k]:
                            continue
                        # consider alphabetical order
                        if left_operands[j] <= right_operands[k]:
                            f = '('+left_operands[j]+')'+op+'('+right_operands[k]+')'
                            if f not in formulas[l]:
                                formulas[l].append(f)
                        else:
                            f = '('+right_operands[k]+')'+op+'('+left_operands[j]+')'
                            if f not in formulas[l]:
                                formulas[l].append(f)


        # considering causal dependency
        if binary_op == 'and':
            for item in causal_dependency:
                # if atom1 is in the past of atom2, formulas of type atom2 and ev(atom1) are not allowed
                remove_formula_1 = '(ev_[tau_1,tau_2]('+causal_dependency[item]+'[t]>=0))' + 'and' + '(' + item + '[t]>=0)'
                remove_formula_1_reorder = '(' + item + '[t]>=0)'+ 'and' + '(ev_[tau_1,tau_2]('+causal_dependency[item]+'[t]>=0))'
                if remove_formula_1 in formulas[l]:
                    formulas[l].remove(remove_formula_1)
                if remove_formula_1_reorder in formulas[l]:
                    formulas[l].remove(remove_formula_1_reorder)


                # if atom1 is in the past of atom2, formulas of type ev(atom1) and ev(atom1) are not allowed
                remove_formula_2 = '(ev_[tau_1,tau_2]('+causal_dependency[item]+'[t]>=0))' + 'and' + '(ev_[tau_1,tau_2]('+item+'[t]>=0))'
                remove_formula_2_reorder = '(ev_[tau_1,tau_2]('+item+'[t]>=0))' + 'and' + '(ev_[tau_1,tau_2]('+causal_dependency[item]+'[t]>=0))'

                if remove_formula_2 in formulas[l]:
                    formulas[l].remove(remove_formula_2)
                if remove_formula_2_reorder in formulas[l]:
                    formulas[l].remove(remove_formula_2_reorder)


                if delay_between_task > 0:
                    # if delay_between_task > 0, formulas of type ev(atom1 and atom2) are not allowed
                    remove_formula_3 = 'ev_[tau_1,tau_2](('+causal_dependency[item]+'[t]>=0)' + 'and' + '('+item+'[t]>=0))'
                    remove_formula_3_reorder = 'ev_[tau_1,tau_2](('+item+'[t]>=0)' + 'and' + '('+causal_dependency[item]+'[t]>=0))'

                    if remove_formula_3 in formulas[l]:
                        formulas[l].remove(remove_formula_3)
                    if remove_formula_3_reorder in formulas[l]:
                        formulas[l].remove(remove_formula_3_reorder)

                
def generate_formulas(max_formula_length, predicates=None, operators=None, causal_dependency={}, delay_between_task=0):

    if not predicates:
        predicates = ['robot_at_xy>=0', 'item_on_robot>=0']

    if not operators:
        unary_operators = ['ev']
        binary_operators = ['and']

    else:
        ops_type = {'ev':'unary', 
                'alw':'unary', 
                'not':'unary', 
                'until':'binary', 
                'and':'binary', 
                'or':'binary', 
                '=>':'binary'}

        unary_operators = []
        binary_operators = []

        for op in operators:
            if ops_type[op] == 'unary':
                unary_operators.append(op)
            else:
                binary_operators.append(op)

        if 'ev' not in unary_operators:
            unary_operators.append('ev')

            

    is_temporal = {'ev': True, 
                    'alw': True, 
                    'not': False, 
                    'until': True, 
                    'and': False, 
                    'or': False, 
                    '=>': False}

    commutes = {'until': False, 
                'and': True, 
                'or': True, 
                '=>': False}

    formulas = DefaultDict(list)
    for l in range(1, max_formula_length+1):
        if l==1:
            enumerate_predicates(formulas, predicates)
        elif l==2:
            apply_unary_operators(formulas, l, unary_operators, is_temporal)
        else:
            apply_unary_operators(formulas, l, unary_operators, is_temporal)
            apply_binary_operators(formulas, l, binary_operators, is_temporal, commutes, causal_dependency, delay_between_task=delay_between_task)

    return formulas
#------------------------------
def get_formula_length(phrases_len, conjunctions_len, adverbs_len):

    # because n phrases need n - 1 connectors
    lower_bound = phrases_len + phrases_len - 1

    # because each phrase needs an F operator
    upper_bound = 2*phrases_len + conjunctions_len + adverbs_len
    return lower_bound, upper_bound








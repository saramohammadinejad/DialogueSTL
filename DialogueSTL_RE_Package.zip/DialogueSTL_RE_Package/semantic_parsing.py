import heapq
import re
from collections import defaultdict

from bert_embedding import (compute_operator_embeddings,
                            compute_phrase_embedding, rank_atoms,
                            rank_operators)
from STL_enumerate import generate_formulas, get_formula_length
from utils import nl_split


def find_causal_dependency(phrases, conjunctions, adverbs, best_atoms, best_operators, interactions):
    causal_dependency = {}
    delay_between_task = None
    for i in range(len(conjunctions)):
        if i+1 >= len(phrases):
            break
        op = best_operators[conjunctions[i]]
        if op == 'and':
            if interactions:
                print("*** interaction with user: getting order of tasks")
                question = "Should the tasks " + phrases[i]+ ' and '+ phrases[i+1]+' run in sequence? Y/N'
                answer = interactions[question]
            else:
                answer = input(f"\nShould the tasks " + '\033[1m' + phrases[i]+ '\033[0m'+ ' and '+ '\033[1m' + phrases[i+1]+'\033[0m'+ ' run in sequence? Y/N\n')

            if interactions:
                print("*** interaction with user: getting operator parameters")
                delay_between_task = interactions["In how many seconds after the first task is done the second task should finish?"]
            else:
                delay_between_task = int(input("\nIn how many seconds after the first task is done the second task should finish?\n"))
            if answer == 'Y':
                print("\n\n")
                independent = best_atoms[phrases[i]]
                dependent = best_atoms[phrases[i+1]]
                
                causal_dependency[dependent] = independent

        if op == 'until':
            if interactions:
                print("*** interaction with user: getting operator parameters")
                delay_between_task = interactions["How much delay between tasks is accepted?"]
            else:
                delay_between_task = int(input("How much delay between tasks is accepted?"))


    for i in range(len(adverbs)):
        if i+1 >= len(phrases):
            break
        op = best_operators[adverbs[i]]
        if op == 'and':
            if best_atoms[phrases[i+1]] in causal_dependency:
                continue

            if interactions:
                print("*** interaction with user: getting order of tasks")
                question = "Should the tasks " + phrases[i]+ ' and '+  phrases[i+1]+' run in sequence? Y/N'
                answer = interactions[question]
            else:
                answer = input(f"\nShould the tasks " + '\033[1m' + phrases[i]+ '\033[0m'+ ' and '+ '\033[1m' + phrases[i+1]+'\033[0m'+ ' run in sequence? Y/N\n')

            if interactions:
                print("*** interaction with user: getting operator parameters")
                delay_between_task = interactions["In how many seconds after the first task is done the second task should finish?"]
            else:
                delay_between_task = int(input("\nIn how many seconds after the first task is done the second task should finish?\n"))
            if answer == 'Y':
                print("\n\n")
                independent = best_atoms[phrases[i]]
                dependent = best_atoms[phrases[i+1]]
                
                causal_dependency[dependent] = independent

        if op == 'until':
            if interactions:
                print("*** interaction with user: getting operator parameters")
                delay_between_task = interactions["How much delay between tasks is accepted?"]
            else:
                delay_between_task = int(input("How much delay between tasks is accepted?"))

    return causal_dependency, delay_between_task 

def infer_task_type(best_atoms, best_ops):
    constraint_atoms = {'robot_at_wall', 'robot_at_water'}
    task_type = []
    if 'not' in best_ops.values() or (len(set(best_atoms.values()).intersection(constraint_atoms))>0 and len(best_atoms)==1):
        task_type.append('constraint')
    if 'or' in best_ops.values():
        task_type.append('multiple_choice')
    if '=>' in best_ops.values():
        task_type.append('conditional')
    if ('and' in best_ops.values()) or ('until' in best_ops.values()):
        task_type.append('sequence')
    if len(best_atoms) == 1:
        task_type.append('single')

    if len(task_type)==0 and len(best_atoms) == 2:
        task_type.append('sequence')

    return task_type

def nl_to_PSTL(nl, model, tokenizer, atom_classifier, tagger, interactions):

    nl = re.sub("n't", " not", nl)
    nl = re.sub("it's", "it is", nl)
    nl = re.sub("'s", " is", nl)
    nl = re.sub("'", "", nl)

    phrases, conjunctions, adverbs, after_if_phrase = nl_split(nl, tagger)
    
    operator_embeddings = compute_operator_embeddings(model, tokenizer)

    conjunctions_embeddings = compute_phrase_embedding(conjunctions, model, tokenizer)
    adverbs_embeddings = compute_phrase_embedding(adverbs, model, tokenizer)

    ranked_atoms = rank_atoms(atom_classifier, phrases, interactions)

    best_atoms = {}
    atom_counts = defaultdict(int) # for the case that one atom happens more that 1 time
    for phrase in ranked_atoms:
        atom = heapq.heappop(ranked_atoms[phrase])[1]
        if atom == 'non_task':
            phrases.remove(phrase)
            continue
        best_atoms[phrase] = atom
        atom_counts[atom] += 1

    ranked_operators = rank_operators(operator_embeddings, conjunctions_embeddings, adverbs_embeddings)

    
    best_operators = {}
    for conj in ranked_operators:
        op = heapq.heappop(ranked_operators[conj])[1]
        best_operators[conj] = op


    task_type = infer_task_type(best_atoms, best_operators)

    atoms_param_values, time_params_value = find_params(nl, best_atoms, task_type, interactions)

    causal_dependency = {}
    delay_between_task = 0
    if 'and' in best_operators.values() or 'until' in best_operators.values() :
        causal_dependency, delay_between_task = find_causal_dependency(phrases, conjunctions,adverbs, best_atoms, best_operators, interactions)

        time_params_value.append(delay_between_task)


    lower_bound, upper_bound = get_formula_length(len(phrases), len(conjunctions), len(adverbs))



    # due to memory limitations
    upper_bound = min(9, upper_bound)

    
    formulas = generate_formulas(max_formula_length=upper_bound, 
                                predicates=list(best_atoms.values()), 
                                operators=list(best_operators.values()),
                                causal_dependency=causal_dependency,
                                delay_between_task=delay_between_task)

    if after_if_phrase:
        after_if_atom = best_atoms[after_if_phrase]
    else:
        after_if_atom = None

    return formulas, lower_bound, upper_bound, atoms_param_values, time_params_value, best_atoms, best_operators, task_type, after_if_atom

def find_params(nl, atoms, task_type, interactions=None):
    
    nl = re.sub('[()]', ' ', nl) #remove paratheses
    nl = re.sub('[,]', ' ', nl) #remove comma
    nl = re.sub('[.]', ' ', nl) #remove dot

    splitted_nl = nl.split()

    # to extract params from NL for atoms and operators
    atom_params_needed={
    'robot_at_xy':['location'],
    'item_at_xy':['location', 'item_id'],
    'item_on_robot':['item_id'],
    'robot_at_water':[],
    'robot_at_dry':[],
    'robot_at_wall':[],
    'lamp_on':[],
    'lamp_off':[],
    'fire_on':[],
    'fire_off':[],
    'door_opened': [],
    'door_closed': [],
    'charger_plugged':[],
    'charger_unplugged':[],
    'robot_is_sitting_on_chair':[],
    'robot_is_standing_up':[]
    }

    #purple cube
    available_items_11 = [
    'purple key',
    'purple cube',
    'purple box',
    'purple block',
    'purple square',
    'purple cuboid',
    'purple object']

    #green cube
    available_items_12 = [
    'green key',
    'green cube',
    'green box',
    'green block',
    'green square',
    'green cuboid',
    'green object']

    available_items_2 = [
    'key',
    'cube',
    'box',
    'block',
    'square',
    'cuboid']

    atoms_params = {}

    for phrase, atom in atoms.items():
        if atom == 'non_task':
            continue
        atoms_params[atom] = {}
        phrase_start = splitted_nl.index(phrase.split()[0])
        window_length = 10
        if 'location' in atom_params_needed[atom]:
            atoms_params[atom]['location'] = []
            # look for first two digits in the window 
            # of length 5 after the phrase_start
            for i in range(phrase_start+1, (phrase_start+window_length)):
                if i >= len(splitted_nl):
                    break
                if splitted_nl[i].isdigit():
                    atoms_params[atom]['location'].append(int(splitted_nl[i]))

        if  'item_id' in atom_params_needed[atom]:
            atoms_params[atom]['item_id'] = None
            item_found = False
            for item in available_items_11:
                color = item.split()[0]
                shape = item.split()[1]

                if color in splitted_nl[phrase_start:phrase_start+window_length] and \
                    shape in splitted_nl[phrase_start:phrase_start+window_length]:
                    atoms_params[atom]['item_id'] = ('purple', 'cube')
                    item_found = True

            for item in available_items_12:
                color = item.split()[0]
                shape = item.split()[1]
                if color in splitted_nl[phrase_start:phrase_start+window_length] and \
                    shape in splitted_nl[phrase_start:phrase_start+window_length]:
                    atoms_params[atom]['item_id'] = ('green', 'cube')
                    item_found = True

            if not item_found:
                for item in available_items_2:
                    if item in splitted_nl[phrase_start:phrase_start+window_length]:
                        if item == 'key':
                            shape = item
                            color = 'null'
                            atoms_params[atom]['item_id'] = (color, shape)
                            item_found = True
                        else:
                            shape = item
                            if interactions:
                                print("*** interaction with user: getting atom parameters")
                                color = interactions[f"Which {item} do you mean?"]
                            else:
                                color = input(f"Which {item} do you mean?")
                            atoms_params[atom]['item_id'] = (color, shape)
                            item_found = True
                
            if not item_found:
                if interactions:
                    print("*** interaction with user: getting atom parameters")
                    item_ = interactions[f"In '{phrase}', Which item do you mean?"]
                else:
                    item_ = input(f"In '{phrase}', Which item do you mean?")
                color = item_.split()[0]
                shape = item_.split()[1]
                atoms_params[atom]['item_id'] = (color, shape)


    time_keywords = ['seconds', 'minutes', 'time', 'sec', 'min']
    time_numbers = []

    for time_keyword in time_keywords:
        if time_keyword in splitted_nl:
            # search in window 2 before that and in window 2 after that for a number
            ind = splitted_nl.index(time_keyword)
            for i in range(ind-2, ind+2+1):
                if i < 0 or i >= len(splitted_nl):
                    break
                if splitted_nl[i].isdigit():
                    time_numbers.append(splitted_nl[i])

    if len(time_numbers) == 0:
        print("*** interaction with user: getting operator parameters")
        if task_type==['constraint', 'single']:
            if interactions:
                answer = interactions["In how many seconds do you want the constraint to be satisfied?"]
            else:
                answer = input("\nIn how many seconds do you want the constraint to be satisfied?\n")
        elif task_type == ['sequence']:
            if interactions:
                answer = interactions["In how many seconds do you want the first task to finish?"]
            else:
                answer = input("\nIn how many seconds do you want the first task to finish?\n")
        else:
            if interactions:
                answer = interactions["In how many seconds do you want the task to finish?"]
            else:
                answer = input("\nIn how many seconds do you want the task to finish?\n")

        time_numbers.append(answer)

    return atoms_params, time_numbers



    

    
    


  

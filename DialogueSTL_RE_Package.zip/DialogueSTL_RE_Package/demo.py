import math
import os
import time

import pygame
import pygame.freetype

import constants_
from utils import distance, generate_neg_traces, generate_trace


def get_demo(world):
    
    state_colors = {
        'wall': constants_.BLACK,
        'water': constants_.BLUE,
        'dry': constants_.WHITE
        }

    # Create a 2 dimensional array. A two dimensional
    # array is simply a list of lists.
    grid = []
    for row in range(world.height):
        # Add an empty array that will hold each cell
        # in this row
        grid.append([])
        for column in range(world.width):
            grid[row].append(0)  # Append a cell

    for wall in world.wall:
        grid[wall[1]][wall[0]] = 'wall'

    for water in world.water:
        grid[water[1]][water[0]] = 'water'

    robot_icon = pygame.image.load(os.getcwd() + '/icons/robot.png')

    # Initialize pygame
    pygame.init()

    screen = pygame.display.set_mode(constants_.WINDOW_SIZE)

    # Set title of screen
    pygame.display.set_caption("Grid World")
    pygame.display.set_icon(robot_icon)


    # Loop until the user clicks the close button.
    done = False

    # Used to manage how fast the screen updates
    clock = pygame.time.Clock()

    actions = []
    times = []
    states = []
    visit_path = []

    start_time=time.time()

    # -------- Main Program Loop -----------
    while not done:

        # Set the screen background
        screen.fill(constants_.GREY)

        print_robot_position(screen, world.robot_position)


        # Draw the grid
        for row in range(world.height):
            for column in range(world.width):
                color = state_colors['dry']

                if grid[row][column] == 'wall':
                    color = state_colors['wall']

                if grid[row][column] == 'water':
                    color = state_colors['water']
                pygame.draw.rect(
                    screen,
                    color, [(constants_.CELL_MARGIN + constants_.CELL_WIDTH) * column + constants_.CELL_MARGIN,
                            (constants_.CELL_MARGIN + constants_.CELL_HEIGHT) * row + constants_.CELL_MARGIN, 
                            constants_.CELL_WIDTH, constants_.CELL_HEIGHT])

                # drawing the items on the floor
                pos = (column, row) 
                if pos in world.items_on_the_floor:
                    item = world.items_on_the_floor[pos]
                    draw_item_on_floor(screen, item, row, column)


                # drawing the charger
                if column == world.charger['pos'][0] and row == world.charger['pos'][1]:
                    draw_item_on_floor(screen, 'charger', row, column)

                # drawing the fire
                if column == world.fire['pos'][0] and row == world.fire['pos'][1]:
                    draw_item_on_floor(screen, 'fire', row, column, state=world.fire['state'])

                # drawing the chair
                if column == world.chair['pos'][0] and row == world.chair['pos'][1]:
                    draw_item_on_floor(screen, 'chair', row, column)

                # drawing the door
                if column == world.door['pos'][0] and row == world.door['pos'][1]:
                    draw_item_on_floor(screen, 'door', row, column, state=world.door['state'])

                # drawing the lamp
                if column == world.lamp['pos'][0] and row == world.lamp['pos'][1]:
                    draw_item_on_floor(screen, 'lamp', row, column, state=world.lamp['state'])

                # drawing the robot
                if column == world.robot_position[0] and row == world.robot_position[1]:

                    screen.blit(robot_icon, ((constants_.CELL_MARGIN + constants_.CELL_WIDTH) * column + constants_.CELL_MARGIN + (constants_.CELL_WIDTH-constants_.ROBOT_WIDTH)/2,
                            (constants_.CELL_MARGIN + constants_.CELL_HEIGHT) * row + constants_.CELL_MARGIN + (constants_.CELL_HEIGHT-constants_.ROBOT_HEIGHT)/2))
                    


        # showing items on robot on lower part of screen
        x = 50
        y = 550
        items_on_robot_pos_on_screen = {}
        for item in world.items_on_robot:
            draw_items_on_robot(screen, item, x, y)
            items_on_robot_pos_on_screen[(x,y)] = item
            x += 80

            

        for event in pygame.event.get():  # User did something
            if event.type == pygame.QUIT:  # If user clicked close
                done = True  # Flag that we are done so we exit this loop

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    world.move(constants_.LEFT)
                    actions.append([constants_.MOVE, constants_.LEFT])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_RIGHT:
                    world.move(constants_.RIGHT)
                    actions.append([constants_.MOVE, constants_.RIGHT])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_UP:
                    world.move(constants_.UP)
                    actions.append([constants_.MOVE, constants_.UP])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_DOWN:
                    world.move(constants_.DOWN)
                    actions.append([constants_.MOVE, constants_.DOWN])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_p:
                    robot_x = world.robot_position[0]
                    robot_y = world.robot_position[1]
                    pos = (robot_x, robot_y)
                    if pos in world.items_on_the_floor:
                        item = world.items_on_the_floor[pos]
                        world.pick([item])
                        actions.append([constants_.PICK, [item]])
                        times.append(time.time()-start_time)
                        states.append(world.get_current_state())

                if event.key == pygame.K_o:
                    world.open_the_door()
                    actions.append([constants_.OPEN_THE_DOOR])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_c:
                    world.close_the_door()
                    actions.append([constants_.CLOSE_THE_DOOR])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_f:
                    world.turn_on_the_fire()
                    actions.append([constants_.TURN_ON_FIRE])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_g:
                    world.turn_off_the_fire()
                    actions.append([constants_.TURN_OFF_FIRE])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_l:
                    world.turn_on_the_lamp()
                    actions.append([constants_.TURN_ON_LAMP])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_m:
                    world.turn_off_the_lamp()
                    actions.append([constants_.TURN_OFF_LAMP])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_s:
                    world.sit_on_the_chair()
                    actions.append([constants_.SIT_ON_THE_CHAIR])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_t:
                    world.stand_up()
                    actions.append([constants_.STAND_UP])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_u:
                    world.plug_the_charger()
                    actions.append([constants_.PLUG_THE_CHARGER])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                if event.key == pygame.K_v:
                    world.unplug_the_charger()
                    actions.append([constants_.UNPLUG_THE_CHARGER])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

                visit_path.append(world.robot_position)

            if event.type == pygame.MOUSEBUTTONDOWN:
                # User clicks the mouse. Get the position
                click_pos = pygame.mouse.get_pos()

                clicked_item = None
                min_dist = math.inf

                for pos in items_on_robot_pos_on_screen:
                    dist = distance(click_pos, pos)
                    if dist < 64 and dist < min_dist:
                        min_dist = min(min_dist, dist)
                        clicked_item = items_on_robot_pos_on_screen[pos]

                if clicked_item:
                    world.put_on_floor([clicked_item])
                    actions.append([constants_.PUT_ON_FLOOR, [clicked_item]])
                    times.append(time.time()-start_time)
                    states.append(world.get_current_state())

        # 60 frames per second
        clock.tick(60)

        # update the screen with the drawings.
        pygame.display.flip()

    pygame.quit()
    return actions, states, visit_path, times

#------------------------------
def print_robot_position(screen, robot_position):

    # create a font object.
    font = pygame.font.Font(os.getcwd() + '/fonts/Raleway-Black.ttf', 16)

    # create a text surface object,
    # on which text is drawn on it.
    text = font.render('Robot position: '+str(robot_position), True, constants_.BLACK, constants_.GREY)

    # create a rectangular object for the
    # text surface object
    textRect = text.get_rect()

    # set the center of the rectangular object.
    textRect.center = (110, 480)

    # copying the text surface object
    # to the display surface object
    # at the center coordinate.
    screen.blit(text, textRect)


def draw_item_on_floor(screen, item, row, column, state=None):
    black_cube = pygame.image.load(os.getcwd() + '/icons/black_cube.png')
    blue_cube = pygame.image.load(os.getcwd() + '/icons/blue_cube.png')
    blue_cylinder = pygame.image.load(os.getcwd() + '/icons/blue_cylinder.png')
    green_cube = pygame.image.load(os.getcwd() + '/icons/green_cube.png')
    green_cylinder = pygame.image.load(os.getcwd() + '/icons/green_cylinder.png')
    purple_cube = pygame.image.load(os.getcwd() + '/icons/purple_cube.png')
    red_cylinder = pygame.image.load(os.getcwd() + '/icons/red_cylinder.png')
    red_triangle = pygame.image.load(os.getcwd() + '/icons/red_triangle.png')
    key = pygame.image.load(os.getcwd() + '/icons/key.png')

    charger = pygame.image.load(os.getcwd() + '/icons/charger.png')
    fire_on = pygame.image.load(os.getcwd() + '/icons/fire-on.png')
    fire_off = pygame.image.load(os.getcwd() + '/icons/fire-off.png')
    door_closed = pygame.image.load(os.getcwd() + '/icons/door-closed.png')
    door_opened = pygame.image.load(os.getcwd() + '/icons/door-opened.png')
    lamp_on = pygame.image.load(os.getcwd() + '/icons/lamp-on.png')
    lamp_off = pygame.image.load(os.getcwd() + '/icons/lamp-off.png')
    chair = pygame.image.load(os.getcwd() + '/icons/chair.png')



    # This sets the WIDTH and HEIGHT of each grid location
    WIDTH = 40
    HEIGHT = 40


    x = (constants_.CELL_MARGIN + constants_.CELL_WIDTH) * column + constants_.CELL_MARGIN + (WIDTH-constants_.ITEM_WIDTH)/2
    y = (constants_.CELL_MARGIN + constants_.CELL_HEIGHT) * row + constants_.CELL_MARGIN + (HEIGHT-constants_.ITEM_HEIGHT)/2

    if item == ('black', 'cube'): screen.blit(black_cube, (x,y))
    elif item == ('blue', 'cube'): screen.blit(blue_cube, (x,y))
    elif item == ('blue', 'cylinder'): screen.blit(blue_cylinder, (x,y))
    elif item == ('green', 'cube'): screen.blit(green_cube, (x,y))
    elif item == ('green', 'cylinder'): screen.blit(green_cylinder, (x,y))
    elif item == ('purple', 'cube'): screen.blit(purple_cube, (x,y))
    elif item == ('red', 'cylinder'): screen.blit(red_cylinder, (x,y))
    elif item == ('red', 'cylinder'): screen.blit(red_triangle, (x,y))
    elif item == ('null', 'key'): screen.blit(key, (x,y))
    elif item == 'charger': screen.blit(charger, (x,y))
    elif item == 'fire': screen.blit(fire_on, (x,y)) if state == 'on' else screen.blit(fire_off, (x,y))
    elif item == 'door': screen.blit(door_closed, (x,y)) if state == 'closed' else screen.blit(door_opened, (x,y))
    elif item == 'lamp': screen.blit(lamp_on, (x,y)) if state == 'on' else screen.blit(lamp_off, (x,y))
    elif item == 'chair': screen.blit(chair, (x,y))



#------------------------------
def draw_items_on_robot(screen, item, x, y):


    font = pygame.font.Font(os.getcwd() + '/fonts/Raleway-Black.ttf', 16)
    text = font.render('items picked up by robot:', True, constants_.BLACK, constants_.GREY)
    textRect = text.get_rect()
    textRect.center = (130, 510)
    screen.blit(text, textRect)


    black_cube = pygame.image.load(os.getcwd() + '/icons/black_cube.png')
    blue_cube = pygame.image.load(os.getcwd() + '/icons/blue_cube.png')
    blue_cylinder = pygame.image.load(os.getcwd() + '/icons/blue_cylinder.png')
    green_cube = pygame.image.load(os.getcwd() + '/icons/green_cube.png')
    green_cylinder = pygame.image.load(os.getcwd() + '/icons/green_cylinder.png')
    purple_cube = pygame.image.load(os.getcwd() + '/icons/purple_cube.png')
    red_cylinder = pygame.image.load(os.getcwd() + '/icons/red_cylinder.png')
    red_triangle = pygame.image.load(os.getcwd() + '/icons/red_triangle.png')
    key = pygame.image.load(os.getcwd() + '/icons/key.png')

    if item == ('black', 'cube'):
        screen.blit(black_cube, (x,y))
    elif item == ('blue', 'cube'):
        screen.blit(blue_cube, (x,y))
    elif item == ('blue', 'cylinder'):
        screen.blit(blue_cylinder, (x,y))
    elif item == ('green', 'cube'):
        screen.blit(green_cube, (x,y))
    elif item == ('green', 'cylinder'):
        screen.blit(green_cylinder, (x,y))
    elif item == ('purple', 'cube'):
        screen.blit(purple_cube, (x,y))
    elif item == ('red', 'cylinder'):
        screen.blit(red_cylinder, (x,y))
    elif item == ('red', 'triangle'):
        screen.blit(red_triangle, (x,y))
    elif item == ('null', 'key'):
        screen.blit(key, (x,y))

def get_states(world, actions):
    states = []
    for action in actions:
        if action[0] == constants_.MOVE:
            world.move(action[1])
            states.append(world.get_current_state())

        elif action[0]==constants_.PICK:
            robot_x = world.robot_position[0]
            robot_y = world.robot_position[1]
            pos = (robot_x, robot_y)
            if pos in world.items_on_the_floor:
                item = action[1]
                world.pick([item])
                states.append(world.get_current_state())
            else:
                raise(f"{item} not found in current robot position!")

        elif action[0]==constants_.OPEN_THE_DOOR:
            world.open_the_door()
            states.append(world.get_current_state())

        elif action[0] == constants_.CLOSE_THE_DOOR:
            world.close_the_door()
            states.append(world.get_current_state())

        elif action[0] == constants_.TURN_ON_FIRE:
            world.turn_on_the_fire()
            states.append(world.get_current_state())

        elif action[0] == constants_.TURN_OFF_FIRE:
            world.turn_off_the_fire()
            states.append(world.get_current_state())

        elif action[0] == constants_.TURN_ON_LAMP:
            world.turn_on_the_lamp()
            states.append(world.get_current_state())

        elif action[0] == constants_.TURN_OFF_LAMP:
            world.turn_off_the_lamp()
            states.append(world.get_current_state())

        elif action[0] == constants_.SIT_ON_THE_CHAIR:
            world.sit_on_the_chair()
            states.append(world.get_current_state())

        elif action[0] == constants_.STAND_UP:
            world.stand_up()
            states.append(world.get_current_state())

        elif action[0] == constants_.PLUG_THE_CHARGER:
            world.plug_the_charger()
            states.append(world.get_current_state())

        elif action[0] == constants_.UNPLUG_THE_CHARGER:
            world.unplug_the_charger()
            states.append(world.get_current_state())

        else:
            raise("action not found!")

    world.set_to_init_state()

    return states

def read_demo_json_decoding(demo):
    # list to tuple encoding
    actions = []
    for action in demo:
        if action[0]=='pick' or action[0]=='put_on_floor':
            actions.append([action[0], (action[1][0], action[1][1])])
        else:
            actions.append(action)
    return actions

def change_world_state(task, world_obj):
    if task == 3 or task == 12 or task == 14 or task == 15 or task == 16:
        world_obj.fire['state'] = 'on'
    if task == 10:
        world_obj.fire['state'] = 'off'
    if task == 4 or task == 8 or task == 9:
        world_obj.door['state'] = 'closed'
    if task == 6 or task == 7 or task == 10:
        world_obj.lamp['state'] = 'off'
    if task == 13:
        world_obj.door['state'] = 'opened'
   
def generate_traces(task_type, world_obj, demos, task):

    if task_type==['constraint', 'single']:

        states = get_states(world_obj, actions=demos['posetive_demo'])

        # generating the positive and negetive traces
        pos_trace = generate_trace(states)
        max_len_traces = len(states)
    
        states = get_states(world_obj, actions=demos['negative_demo'])
        neg_trace = generate_trace(states)
        all_traces = [pos_trace]+[neg_trace]

        n_traces = len(all_traces)
        max_len_traces = max(max_len_traces, len(states))


    elif task_type == ['multiple_choice']:
        states = get_states(world_obj, actions=read_demo_json_decoding(demos['posetive_demo_1']))
        pos_trace_1 = generate_trace(states)
        neg_traces_1, max_len_traces_1 = generate_neg_traces(pos_trace_1)

        change_world_state(task, world_obj)
        states = get_states(world_obj, actions=read_demo_json_decoding(demos['posetive_demo_2']))
        pos_trace_2 = generate_trace(states)
        neg_traces_2, max_len_traces_2 = generate_neg_traces(pos_trace_2)

        all_traces = [pos_trace_1] + [pos_trace_2] + neg_traces_1 + neg_traces_2
        max_len_traces = max(max_len_traces_1, max_len_traces_2)
        n_traces = len(all_traces)

    else:
        states = get_states(world_obj, actions=read_demo_json_decoding(demos['posetive_demo']))
        pos_trace = generate_trace(states)
        neg_traces, max_len_traces = generate_neg_traces(pos_trace)
        all_traces = [pos_trace] + neg_traces
        n_traces = len(all_traces)

    return all_traces, n_traces, max_len_traces



            





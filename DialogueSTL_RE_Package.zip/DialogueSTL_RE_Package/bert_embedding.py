# https://towardsdatascience.com/3-types-of-contextualized-word-embeddings-from-bert-using-transfer-learning-81fcefe3fe6d
# https://github.com/arushiprakash/MachineLearning/blob/main/BERT%20Word%20Embeddings.ipynb
# Importing the relevant modules
import asyncio
import heapq
from collections import defaultdict

import numpy as np
import torch
from scipy.spatial.distance import cosine


def bert_text_preparation(text, tokenizer):
    """Preparing the input for BERT
    
    Takes a string argument and performs
    pre-processing like adding special tokens,
    tokenization, tokens to ids, and tokens to
    segment ids. All tokens are mapped to seg-
    ment id = 1.
    
    Args:
        text (str): Text to be converted
        tokenizer (obj): Tokenizer object
            to convert text into BERT-re-
            adable tokens and ids
        
    Returns:
        list: List of BERT-readable tokens
        obj: Torch tensor with token ids
        obj: Torch tensor segment ids
    
    
    """
    marked_text = "[CLS] " + text + " [SEP]"
    tokenized_text = tokenizer.tokenize(marked_text)
    indexed_tokens = tokenizer.convert_tokens_to_ids(tokenized_text)
    segments_ids = [1]*len(indexed_tokens)
   
    # Convert inputs to PyTorch tensors
    tokens_tensor = torch.tensor([indexed_tokens])
    segments_tensors = torch.tensor([segments_ids])

    return tokenized_text, tokens_tensor, segments_tensors


def get_bert_embeddings(tokens_tensor, segments_tensors, model):
    """Get embeddings from an embedding model
    
    Args:
        tokens_tensor (obj): Torch tensor size [n_tokens]
            with token ids for each token in text
        segments_tensors (obj): Torch tensor size [n_tokens]
            with segment ids for each token in text
        model (obj): Embedding model to generate embeddings
            from token and segment ids
    
    Returns:
        list: List of list of floats of size
            [n_tokens, n_embedding_dimensions]
            containing embeddings for each token
    
    """
    
    # Gradient calculation id disabled
    # Model is in inference mode
    with torch.no_grad():
        outputs = model(tokens_tensor, segments_tensors)
        # Removing the first hidden state
        # The first state is the input state
        hidden_states = outputs[2][1:]

    # Getting embeddings from the final BERT layer
    token_embeddings = hidden_states[-1]
    # Collapsing the tensor into 1-dimension
    token_embeddings = torch.squeeze(token_embeddings, dim=0)
    # Converting torchtensors to lists
    list_token_embeddings = [token_embed.tolist() for token_embed in token_embeddings]

    return list_token_embeddings

# COMPUTING OPERATORS EMBEDDINGS
def compute_operator_embeddings(model, tokenizer):
    # we can enrich these synonyms in a feedback loop
    operator_synonyms={
    'ev':['eventually','finally'],
    'alw':['always', 'globally'],
    'not':['not', "don't", "never"], 
    'until':['until','before','prior', 'then'],
    'and': ['and','plus', 'then', 'next'],
    'or':['or','either'],
    '=>':['if', 'implies','indicates']
    }
    operator_embeddings = defaultdict(list)
    for op in operator_synonyms:
        synonym_embeddings = []
        for synonym in operator_synonyms[op]:
            tokenized_text, tokens_tensor, segments_tensors = bert_text_preparation(synonym, tokenizer)
            list_token_embeddings = get_bert_embeddings(tokens_tensor, segments_tensors, model)
            word_embedding = list_token_embeddings[1]
            synonym_embeddings.append(word_embedding)
        operator_embeddings[op] = np.mean(synonym_embeddings, axis=0)
    return operator_embeddings

def compute_phrase_embedding(phrases, model, tokenizer):
    phrases_embeddings = {}
    for phrase in phrases:
        tokenized_text, tokens_tensor, segments_tensors = bert_text_preparation(phrase, tokenizer)
        list_token_embeddings = get_bert_embeddings(tokens_tensor, segments_tensors, model)
        phrases_embeddings[phrase] = list_token_embeddings

    return phrases_embeddings

def rank_atoms(atom_classifier, phrases_embeddings, interactions):
    ranked_atoms = defaultdict(list)
    for phrase in phrases_embeddings:
        ranked_atoms[phrase] = []

        result = asyncio.run(atom_classifier.parse_message(phrase))
        cnt = 0
        while result['intent']['confidence'] < 0.5:
            #ask user to paraphrase
            if interactions:
                question = "Sorry I don't understand the part '" + phrase + "', could you please paraphrase it?"
                phrase_ = interactions[question]
            else:
                phrase_ = input(f"Sorry I don't understand the part '{phrase}', could you please paraphrase it?")
            result = asyncio.run(atom_classifier.parse_message(phrase_))
            cnt +=1
            if cnt == 3:
                print("Robot failed! :(")
                exit()

        for item in result['intent_ranking']:
            heapq.heappush(ranked_atoms[phrase], [-item['confidence'], item['name']])
    return ranked_atoms


def rank_operators(operator_embeddings, conjunctions_embeddings, adverbs_embeddings):
    ranked_operators = defaultdict(list)
    for conjunc in conjunctions_embeddings:
        for op in operator_embeddings:
            sim = 1 - cosine(operator_embeddings[op], conjunctions_embeddings[conjunc][1])
            heapq.heappush(ranked_operators[conjunc], [-sim, op])
        
    for adverb in adverbs_embeddings:
        for op in operator_embeddings:
            sim = 1 - cosine(operator_embeddings[op], adverbs_embeddings[adverb][1])
            heapq.heappush(ranked_operators[adverb], [-sim, op])

    return ranked_operators

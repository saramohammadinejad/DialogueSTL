import math

import matlab.engine
import numpy as np

from flair.data import Sentence



def distance(p1, p2, norm='L1'):
    '''
    Returns the distance between two 2D points p1 and p2, represented as tuples.
    'L1': Manhattan or Taxi-cab distance.
    'L2': Euclidean distance.
    Feel free to add any distance metric and extend to multi-dimensional spaces. :)
    '''
    if norm == 'L1':
        dist = abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])
    elif norm == 'L2':
        dist = (p1[0] - p2[0])**2 + (p1[1] - p2[1])**2
        dist = np.sqrt(dist)
    return dist
#------------------------------
def min_distance(p1, points, norm='L1'):
    min_dist = math.inf
    for p in points:
        dist = distance(p1, p, norm)
        if dist < min_dist:
            min_dist = dist

    return min_dist
#------------------------------
class State:
    def __init__(self, robot_position, items_on_robot, items_positions, items_on_the_floor, charger, chair, fire, door, lamp):
        self.robot_position = robot_position
        self.items_on_robot = items_on_robot
        self.items_positions = items_positions
        self.items_on_the_floor = items_on_the_floor
        self.charger = charger
        self.chair = chair
        self.fire = fire
        self.door = door
        self.lamp = lamp
#------------------------------
class Trace:
    """
    Each trace is a list of States and each state happens at a time instance
    """
    def __init__(self, time_instances, states):
        self.time_instances = time_instances
        self.states = states
#------------------------------
def generate_trace(states):
    time_instances = list(range(len(states)))
    return Trace(time_instances, states)
#------------------------------
def generate_neg_traces(trace):
    neg_traces = []
    trace_length = len(trace.time_instances)
    max_len_traces = trace_length

    # subsets of positive trace
    for i in range(2, trace_length):
        time_instances = trace.time_instances[0:i]
        states = trace.states[0:i]
        neg_traces.append(Trace(time_instances, states))

    return neg_traces, max_len_traces
#-------------------------------
# https://www.guru99.com/pos-tagging-chunking-nltk.html
# https://stackoverflow.com/questions/13236138/is-there-an-online-application-that-automatically-draws-tree-structures-for-phra
# http://nlpprogress.com/english/part-of-speech_tagging.html
#https://huggingface.co/flair/pos-english?text=go+to+location+and+sit+on+the+chair
#https://github.com/flairNLP/flair/

def nl_split(nl, tagger):
    remove_words = ['do', 'does', 'Do', 'Does']

    # make example sentence
    sentence = Sentence(nl)

    # predict NER tags
    tagger.predict(sentence)

    tokens_tag = []
    for entity in sentence.get_spans('pos'):
        result = entity.to_dict()
        if result['text'] not in remove_words:
            tokens_tag.append((result['text'], result['labels'][0].value))


    phrases = [""]
    verb_VBP = False
    verb_VBZ = False
    after_if_phrase = None

    for i in range(len(tokens_tag)-1, -1, -1):
        if (tokens_tag[i][0]=='if' or  tokens_tag[i][0]=='If') and after_if_phrase==None:
            after_if_phrase = phrases[len(phrases)-2]
        if tokens_tag[i][1] == 'VB' or tokens_tag[i][1] == 'VBG' or tokens_tag[i][1] == 'VBD':
            phrases[-1] = tokens_tag[i][0] + ' ' + phrases[-1]
            if i>0: phrases.append("")
       
        elif tokens_tag[i][1] == 'VBP': #example: are
            phrases[-1] = tokens_tag[i][0] + ' ' + phrases[-1]
            verb_VBP = True

        elif tokens_tag[i][1] == 'VBZ': #example: is
            phrases[-1] = tokens_tag[i][0] + ' ' + phrases[-1]
            verb_VBZ = True

        elif (verb_VBP or verb_VBZ):
            phrases[-1] = tokens_tag[i][0] + ' ' + phrases[-1]
            if i>0: phrases.append("")
            verb_VBP = False
            verb_VBZ = False

        elif i+3 < len(tokens_tag) and (tokens_tag[i][1] == 'CC' or tokens_tag[i][1] == 'IN') and \
            (tokens_tag[i+1][1][0] == 'V' or tokens_tag[i+2][1][0] == 'V' or tokens_tag[i+3][1][0] == 'V'):
            continue

        elif tokens_tag[i][1] == ',' or tokens_tag[i][1] == '.' or tokens_tag[i][1]=='UH':
            continue

        elif tokens_tag[i][1] == 'RB':
            if (i > 1 and tokens_tag[i-1][1][0] == 'V'):
                phrases[-1] = tokens_tag[i][0] + ' ' + phrases[-1] # example: fire is on
            else:
                continue

        else:
            phrases[-1] = tokens_tag[i][0] + ' ' + phrases[-1]

    if '' in phrases: phrases.remove('')
    phrases = [phrase.strip() for phrase in phrases[::-1]] # reverse the phrase list and remove beginning and end spaces
    
   

    # we look for conjunctions (CC) and subordinating conjunctions (IN)
    # in a window that connects sentences (at the end of each phrase)
    # we look for adverbs (RB) in the beginning of each phrase

    # we look for conjunctions (CC) and subordinating conjunctions (IN) in 
    # window of length n=3 before verbs

    # removed words
    removed_words = ['on', 'in']


    conjunctions = []
    adverbs = []
    verb_found = False
    cnt = 0
    window_size = 3
    for i in range(len(tokens_tag)-1, -1, -1):
        if tokens_tag[i][1][0] == 'V':
            verb_found = True
            cnt = 0
        else:
            cnt = cnt + 1

        if tokens_tag[i][0] in removed_words:
            continue

        if verb_found and cnt <= window_size and (tokens_tag[i][1] == 'CC' \
            or tokens_tag[i][1] == 'IN'):
            conjunctions.append(tokens_tag[i][0])

        if tokens_tag[i][1] == 'RB':
            adverbs.append(tokens_tag[i][0])


    if after_if_phrase:
        after_if_phrase = after_if_phrase.strip()

    return phrases, conjunctions, adverbs, after_if_phrase
#------------------------------
def set_time_params(formula, time_params_value):
    import re
    if len(time_params_value) == 1:
        formula = formula.replace('tau_1', '0')
        formula = formula.replace('tau_2', str(time_params_value[0]))
    if len(time_params_value) == 2:
        matches = re.finditer('tau_2', formula)
        matches_positions = [match.start() for match in matches]
        if len(matches_positions) == 1:
            formula = formula.replace('tau_1', '0')
            formula = formula.replace('tau_2', str(time_params_value[0]))
        elif len(matches_positions) == 2:
            formula = formula[0:matches_positions[0]]+ str(time_params_value[0])+formula[matches_positions[0]+5:]
            formula = formula.replace('tau_2', str(time_params_value[1]))
            formula = formula.replace('tau_1', '0')
    return formula
#------------------------------
def compute_stl_robustness(states, eng, grid):
    from robustness_computation import (item_on_robot_ro, lamp_on_ro,
                                        robot_at_wall_ro)

    trace = generate_trace(states)

    ro_lamp_on =lamp_on_ro(trace)
    ro_item_on_robot=item_on_robot_ro(trace, item=('purple', 'cube'))

    t = list(range(len(states)))
    t = matlab.int64(t)

    stl = 'ev_[0,10]((ev_[0,6](item_on_robot[t]>=0))and(lamp_on[t]>=0))'
 

    ro_lamp_on = matlab.double(ro_lamp_on)
    ro_item_on_robot = matlab.double(ro_item_on_robot)
    ro = eng.CheckSTLSpec( stl, t, 'lamp_on', ro_lamp_on, 'item_on_robot', ro_item_on_robot)


    #safety formula
    ro_robot_at_wall=robot_at_wall_ro(trace, grid)
    ro_robot_at_wall = matlab.double(ro_robot_at_wall)
    stl_safety_wall = 'alw(not(robot_at_wall[t]>=0))'
    ro_safety_wall = eng.CheckSTLSpec(stl_safety_wall, t, 'robot_at_wall', ro_robot_at_wall)


    ro_safety = ro_safety_wall

    return ro, ro_safety
#------------------------------
def compute_str_accuracy(reference_stl, pred_stl):
    
    # padding
    if len(pred_stl) < len(reference_stl):
        pred_stl_ = pred_stl + '#'*(len(reference_stl)-len(pred_stl))
    else:
        pred_stl_ = pred_stl

    correct_counts = 0
    for i in range(len(reference_stl)):
        if reference_stl[i]==pred_stl_[i]:
            correct_counts += 1

    str_acc=correct_counts/len(reference_stl)

    return str_acc
#------------------------------
def prune_formulas(all_formulas, atoms_param_values):
    atoms = list(atoms_param_values.keys())

    
    pruned_formulas = []
    for formula in all_formulas:
        # drop formulas that contain more than one instances of an atom

        contain_more_than_one_instances_of_atom = False
        for atom in atoms:
            if formula.count(atom) > 1:
                contain_more_than_one_instances_of_atom = True
        if contain_more_than_one_instances_of_atom:
            continue
        # drop formulas that don't contain all atoms
        if all([atom in formula for atom in atoms]):
            pruned_formulas.append(formula)

    return pruned_formulas
#------------------------------
def generate_candidate_stl_formulas(formulas, lower_bound, upper_bound, atoms_param_values, time_params_value):
    # get formulas with length in range [lower_bound, upper_bound]
    all_formulas = []
    for i in range(lower_bound, upper_bound+1):
        all_formulas.extend(formulas[i])

    # drop formulas that don't contain all atoms
    all_formulas = prune_formulas(all_formulas, atoms_param_values)

    # set parameters of formula
    stl_formulas = []
    for formula in all_formulas:
        stl = set_time_params(formula, time_params_value)
        stl_formulas.append(stl)

    return stl_formulas




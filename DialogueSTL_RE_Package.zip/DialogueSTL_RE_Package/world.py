# This code is a modified version of ltltalk world
import copy
import warnings

import constants_
from utils import State


class GridWorld:

    def __init__(self, world_description):

        self.width = world_description["width"]
        self.height =  world_description["height"]

        self.robot_position = (world_description["robot"]["x"], world_description["robot"]["y"])

        self.wall= []
        self.water = []
        self.charger = {'pos':None, 'state':None}
        self.chair = {'pos':None, 'state':None}
        self.fire = {'pos':None, 'state':None}
        self.door = {'pos':None, 'state': None}
        self.lamp = {'pos':None, 'state': None}
   
        self.items_on_the_floor = {}
        self.items_positions = {}

        for object in world_description["objects_on_floor"]:
            pos = (object["x"],object["y"])
            if object["type"] == "wall":
                self.wall.append(pos)
            elif object["type"] == "water":
                self.water.append(pos)
            elif object["type"] == "charger":
                self.charger['pos'] = pos
                self.charger['state'] = object["shape"]
            elif object["type"] == "chair":
                self.chair['pos'] = pos
                self.chair['state'] = object["shape"]
            elif object["type"] == "fire":
                self.fire['pos'] = pos
                self.fire['state'] = object["shape"]
            elif object["type"] == "door":
                self.door['pos'] = pos
                self.door['state'] = object["shape"]
            elif object["type"] == "lamp":
                self.lamp['pos'] = pos
                self.lamp['state'] = object["shape"]
            elif object["type"] == "item":
                found_item = (object["color"], object["shape"])
                self.items_on_the_floor[pos] = found_item
                self.items_positions[found_item] = pos

        self.items_on_robot = set()
        for object in world_description["objects_on_robot"]:
            found_item = (object["color"], object["shape"])
            self.items_on_robot.add(found_item)

        self.crashed_into_wall = False

        # Keep a copy of initial state
        self.init_state = State(copy.deepcopy(self.robot_position), 
                                copy.deepcopy(self.items_on_robot), 
                                copy.deepcopy(self.items_positions),
                                copy.deepcopy(self.items_on_the_floor),
                                copy.deepcopy(self.charger),
                                copy.deepcopy(self.chair),
                                copy.deepcopy(self.fire),
                                copy.deepcopy(self.door),
                                copy.deepcopy(self.lamp))


        self.all_possible_actions = {('move', 'left'):0, ('move', 'right'):1, ('move', 'up'):2, ('move', 'down'):3, 
        ('pick', ('green', 'cube')):4, ('pick', ('purple', 'cube')):5, ('pick', ('null', 'key')):6, 
        ('put_on_floor', ('green', 'cube')):7, ('put_on_floor', ('purple', 'cube')):8, ('put_on_floor', ('null', 'key')):9, 
        ('turn_off_lamp'):10, ('turn_on_lamp'):11, ('turn_off_fire'):12, ('turn_on_fire'):13, 
        ('sit_on_chair'):14, ('stand_up'):15, ('open_the_door'):16, ('close_the_door'):17, 
        ('plug_the_charger'):18, ('unplug_the_charger'):19}


        self.all_possible_actions_keys = {0:('move', 'left'), 1:('move', 'right'), 2:('move', 'up'), 3:('move', 'down'), 
        4:('pick', ('green', 'cube')), 5:('pick', ('purple', 'cube')), 6:('pick', ('null', 'key')), 
        7:('put_on_floor', ('green', 'cube')), 8:('put_on_floor', ('purple', 'cube')), 9:('put_on_floor', ('null', 'key')), 
        10:['turn_off_lamp'], 11:['turn_on_lamp'], 12:['turn_off_fire'], 13:['turn_on_fire'], 
        14:['sit_on_chair'], 15:['stand_up'], 16: ['open_the_door'], 17:['close_the_door'], 
        18:['plug_the_charger'], 19:['unplug_the_charger']}

    def set_to_init_state(self):
        
        self.robot_position = copy.deepcopy(self.init_state.robot_position)
        self.items_on_robot = copy.deepcopy(self.init_state.items_on_robot)
        self.items_positions = copy.deepcopy(self.init_state.items_positions)
        self.items_on_the_floor = copy.deepcopy(self.init_state.items_on_the_floor)
        self.charger = copy.deepcopy(self.init_state.charger)
        self.chair = copy.deepcopy(self.init_state.chair)
        self.fire = copy.deepcopy(self.init_state.fire)
        self.door = copy.deepcopy(self.init_state.door)
        self.lamp = copy.deepcopy(self.init_state.lamp)

    def move(self, direction):
        roboX = self.robot_position[0]
        roboY = self.robot_position[1]
        

        newPosition = (roboX, roboY)

        if direction == constants_.LEFT:
            if roboX == 0:
                self.crashed_into_wall = True
            else:
                newPosition = (roboX-1, roboY)

        elif direction == constants_.RIGHT:
            if roboX == self.width - 1:
                self.crashed_into_wall = True
            else:
                newPosition = (roboX+1, roboY)

        elif direction == constants_.UP:
            if roboY == 0:
                self.crashed_into_wall = True
            else:
                newPosition = (roboX, roboY-1)

        elif direction == constants_.DOWN:
            if roboY == self.height - 1:
                self.crashed_into_wall = True
            else:
                newPosition = (roboX, roboY+1)

        self.robot_position = newPosition

    def pick(self, color_shape_pairs):
        for item_description in color_shape_pairs:
            if self.robot_position not in self.items_on_the_floor:
                pass
            elif self.items_on_the_floor[self.robot_position] != item_description:
                pass
            else:
                self.items_on_robot.add(item_description)
                del self.items_on_the_floor[self.robot_position]
                del self.items_positions[item_description]

    def put_on_floor(self, color_shape_pairs):
        for item_description in color_shape_pairs:
            if item_description not in self.items_on_robot:
                pass
            elif self.robot_position in self.items_on_the_floor:
                pass
            else:
                self.items_on_the_floor[self.robot_position] = item_description
                self.items_on_robot.remove(item_description)
                self.items_positions[item_description] = self.robot_position
    
    # press key:o
    def open_the_door(self):
        robot_x = self.robot_position[0]
        robot_y = self.robot_position[1]
        pos = (robot_x, robot_y)
        if self.door['pos'] == pos:
            if self.door['state'] == 'closed':
                self.door['state'] = 'opened'
            else:
                warnings.warn("Door is already opended!")
        else:
            warnings.warn("No door at this position!")

    # press key:c
    def close_the_door(self):
        robot_x = self.robot_position[0]
        robot_y = self.robot_position[1]
        pos = (robot_x, robot_y)
        if self.door['pos'] == pos:
            if self.door['state'] == 'opened':
                self.door['state'] = 'closed'
            else:
                warnings.warn("Door is already closed!")
        else:
            warnings.warn("No door at this position!")

    # press key:f
    def turn_on_the_fire(self):
        robot_x = self.robot_position[0]
        robot_y = self.robot_position[1]
        pos = (robot_x, robot_y)
        if self.fire['pos'] == pos:
            if self.fire['state'] == 'off':
                self.fire['state'] = 'on'
            else:
                warnings.warn("Fire is already on!")
        else:
            warnings.warn("No fire at this position!")       

    # press key:g
    def turn_off_the_fire(self):
        robot_x = self.robot_position[0]
        robot_y = self.robot_position[1]
        pos = (robot_x, robot_y)
        if self.fire['pos'] == pos:
            if self.fire['state'] == 'on':
                self.fire['state'] = 'off'
            else:
                warnings.warn("Fire is already off!")
        else:
            warnings.warn("No fire at this position!")

    # press key:l
    def turn_on_the_lamp(self):
        robot_x = self.robot_position[0]
        robot_y = self.robot_position[1]
        pos = (robot_x, robot_y)
        if self.lamp['pos'] == pos:
            if self.lamp['state'] == 'off':
                self.lamp['state'] = 'on'
            else:
                warnings.warn("Lamp is already on!")
        else:
            warnings.warn("No lamp at this position!")       
    
    # press key:m
    def turn_off_the_lamp(self):
        robot_x = self.robot_position[0]
        robot_y = self.robot_position[1]
        pos = (robot_x, robot_y)
        if self.lamp['pos'] == pos:
            if self.lamp['state'] == 'on':
                self.lamp['state'] = 'off'
            else:
                warnings.warn("Lamp is already off!")
        else:
            warnings.warn("No lamp at this position!")
  
    # press key:s
    def sit_on_the_chair(self):
        robot_x = self.robot_position[0]
        robot_y = self.robot_position[1]
        pos = (robot_x, robot_y)
        if self.chair['pos'] == pos:
            if self.chair['state'] == 'no_one_sitted_on_chair':
                self.chair['state'] = 'robot_sitted_on_chair'
            else:
                warnings.warn("Robot is already sitted on chair!")
        else:
            warnings.warn("No chair at this position!")



    # press key:t
    def stand_up(self):
        robot_x = self.robot_position[0]
        robot_y = self.robot_position[1]
        pos = (robot_x, robot_y)
        if self.chair['pos'] == pos:
            if self.chair['state'] == 'robot_sitted_on_chair':
                self.chair['state'] = 'no_one_sitted_on_chair'
            else:
                warnings.warn("Robot is already standed up!")
        else:
            warnings.warn("No chair at this position!")


    # press key:u
    def plug_the_charger(self):
        robot_x = self.robot_position[0]
        robot_y = self.robot_position[1]
        pos = (robot_x, robot_y)
        if self.charger['pos'] == pos:
            if self.charger['state'] == 'not_in_use':
                self.charger['state'] = 'in_use'
            else:
                warnings.warn("Charger is already in use!")
        else:
            warnings.warn("No charger at this location!")


    # press key:v
    def unplug_the_charger(self):
        robot_x = self.robot_position[0]
        robot_y = self.robot_position[1]
        pos = (robot_x, robot_y)
        if self.charger['pos'] == pos:
            if self.charger['state'] == 'in_use':
                self.charger['state'] = 'not_in_use'
            else:
                warnings.warn("Charger is not already in use!")
        else:
            warnings.warn("No charger at this location!")



    def execute_action(self, action):

        """

        action = ['move', 'left']
        action = ['pick', ('red', 'circle')]
        action = ['put_on_floor', ('red', 'circle')]
        .
        .
        .
        """

        if action[0] == 'move':
            self.move(direction=action[1])
        elif action[0] == 'pick':
            self.pick([action[1]])
        elif action[0] == 'put_on_floor':
            self.put_on_floor([action[1]])
        elif action[0] == 'turn_off_lamp':
            self.turn_off_the_lamp()
        elif action[0] == 'turn_on_lamp':
            self.turn_on_the_lamp()
        elif action[0] == 'turn_off_fire':
            self.turn_off_the_fire()
        elif action[0] == 'turn_on_fire':
            self.turn_on_the_fire()
        elif action[0] == 'sit_on_chair':
            self.sit_on_the_chair()
        elif action[0] == 'stand_up':
            self.stand_up()
        elif action[0] == 'open_the_door':
            self.open_the_door()
        elif action[0] == 'close_the_door':
            self.close_the_door()
        elif action[0] == 'plug_the_charger':
            self.plug_the_charger()
        elif action[0] == 'unplug_the_charger':
            self.unplug_the_charger()
        else:
            raise ValueError("action={} does not exists!".format(action[0]))


    def get_current_state(self):
        curr_state = State(self.robot_position, 
            copy.deepcopy(self.items_on_robot), 
            copy.deepcopy(self.items_positions),  
            copy.deepcopy(self.items_on_the_floor),
            copy.deepcopy(self.charger), 
            copy.deepcopy(self.chair), 
            copy.deepcopy(self.fire),
            copy.deepcopy(self.door),
            copy.deepcopy(self.lamp))
        

        return curr_state

    def set_state(self, state):
        self.robot_position = copy.deepcopy(state.robot_position)
        self.items_on_robot = copy.deepcopy(state.items_on_robot)
        self.items_positions = copy.deepcopy(state.items_positions) 
        self.items_on_the_floor = copy.deepcopy(state.items_on_the_floor)
        self.charger = copy.deepcopy(state.charger)
        self.chair = copy.deepcopy(state.chair)
        self.fire = copy.deepcopy(state.fire)
        self.door = copy.deepcopy(state.door)
        self.lamp = copy.deepcopy(state.lamp)


    def simplify_current_state(self):
        item_0 = ('green', 'cube')
        item_1 = ('purple', 'cube')
        item_2 = ('null', 'key')

        if item_0 in self.items_positions:
            item_0_pos = self.items_positions[item_0]
        else:
            item_0_pos = 'on_robot'

        if item_1 in self.items_positions:
            item_1_pos = self.items_positions[item_1]
        else:
            item_1_pos = 'on_robot'

        if item_2 in self.items_positions:
            item_2_pos = self.items_positions[item_2]
        else:
            item_2_pos = 'on_robot'


        if item_0_pos == 'on_robot':
            item_0_pos = self.robot_position
            item_0_on_robot = 10
        else:
            item_0_on_robot = 0

        if item_1_pos == 'on_robot':
            item_1_pos = self.robot_position
            item_1_on_robot = 10
        else:
            item_1_on_robot = 0

        if item_2_pos == 'on_robot':
            item_2_pos = self.robot_position
            item_2_on_robot = 10
        else:
            item_2_on_robot = 0

        lamp_state = 10 if self.lamp['state']=='on' else 0
        chair_state = 10 if self.chair['state']=='robot_sitted_on_chair' else 0
        fire_state = 10 if  self.fire['state']=='on' else 0
        door_state = 10 if  self.door['state']=='opened' else 0
        charger_state = 10 if self.charger['state']=='in_use' else 0

        state = (self.robot_position[0],self.robot_position[1], 
                item_0_pos[0], item_0_pos[1],
                item_1_pos[0], item_1_pos[1],
                item_2_pos[0], item_2_pos[1], 
                item_0_on_robot,
                item_1_on_robot,
                item_2_on_robot,
                lamp_state , 
                chair_state, 
                fire_state, 
                door_state, 
                charger_state)

        return state

    def gen_all_posible_states(self):
        all_grid_locations = []
        for i in range(self.width):
            for j in range(self.height):
                all_grid_locations.append((i,j))

        all_item_locations = all_grid_locations + ['on_robot']
        lamp_states = ['on', 'off']
        chair_states = ['no_one_sitted_on_chair', 'robot_sitted_on_chair']
        fire_states = ['on', 'off']
        door_states = ['opened', 'closed']
        charger_states = ['in_use', 'not_in_use']

        self.all_states = []
        for r_pos in all_grid_locations:
            for item_0_pos in all_item_locations:
                for item_1_pos in all_item_locations:
                    for item_2_pos in all_item_locations:
                        if item_0_pos == item_1_pos and item_1_pos == item_2_pos and item_0_pos!='on_robot':
                            continue
                        for lamp_state in lamp_states:
                            for chair_state in chair_states:
                                for fire_state in fire_states:
                                    for door_state in door_states:
                                        for charger_state in charger_states:
                                            state = (r_pos, item_0_pos, item_1_pos, item_2_pos,
                                            lamp_state, chair_state, fire_state, door_state, charger_state)
                                            self.all_states.append(state)


    def get_all_possible_actions_for_state(self, state):
   
        all_possible_actions = [('move', 'left'), ('move', 'right'), ('move', 'up'), ('move', 'down')]



        r_pos = state.robot_position
        items_on_robot = state.items_on_robot
        items_positions = state.items_positions
        items_on_the_floor = state.items_on_the_floor
        charger_state = state.charger
        chair_state = state.chair
        fire_state = state.fire
        door_state = state.door
        lamp_state = state.lamp

        item_0 = ('green', 'cube')
        item_1 = ('purple', 'cube')
        item_2 = ('null', 'key')

        if item_0 in items_on_robot:
            item_0_pos = 'on_robot'
        else:
            item_0_pos = items_positions[item_0]

        if item_1 in items_on_robot:
            item_1_pos = 'on_robot'
        else:
            item_1_pos = items_positions[item_1]

        if item_2 in items_on_robot:
            item_2_pos = 'on_robot'
        else:
            item_2_pos = items_positions[item_2]

        

        if item_0_pos == 'on_robot':
            all_possible_actions.append(('put_on_floor', ('green', 'cube')))
        elif item_0_pos == r_pos:
            all_possible_actions.append(('pick', ('green', 'cube')))

        if item_1_pos == 'on_robot':
            all_possible_actions.append(('put_on_floor', ('purple', 'cube')))
        elif item_1_pos == r_pos:
            all_possible_actions.append(('pick', ('purple', 'cube')))

        if item_2_pos == 'on_robot':
            all_possible_actions.append(('put_on_floor', ('null', 'key')))
        elif item_2_pos == r_pos:
            all_possible_actions.append(('pick', ('null', 'key')))

        
        if r_pos == self.lamp['pos']:
            if lamp_state == 'on':
                all_possible_actions.append(('turn_off_lamp'))
            else:
                all_possible_actions.append(('turn_on_lamp'))

        if r_pos == self.chair['pos']:
            if chair_state == 'no_one_sitted_on_chair':
                all_possible_actions.append(('sit_on_chair'))
            else:
                all_possible_actions.append(('stand_up'))

        if r_pos == self.fire['pos']:
            if fire_state == 'on':
                all_possible_actions.append(('turn_off_fire'))
            else:
                all_possible_actions.append(('turn_on_fire'))

        if r_pos == self.door['pos']:
            if door_state == 'closed':
                all_possible_actions.append(('open_the_door'))
            else:
                all_possible_actions.append(('close_the_door'))

        if r_pos == self.charger['pos']:
            if charger_state == 'not_in_use':
                all_possible_actions.append(('plug_the_charger'))
            else:
                all_possible_actions.append(('unplug_the_charger'))

        if r_pos[0] == 0: 
            all_possible_actions.remove(('move', 'left'))

        if r_pos[0] == self.width-1:
            all_possible_actions.remove(('move', 'right'))

        if r_pos[1] == 0: 
            all_possible_actions.remove(('move', 'up'))
    
        if r_pos[1] == self.height-1: 
            all_possible_actions.remove(('move', 'down'))

        all_possible_actions_ = []
        for action in all_possible_actions:
             all_possible_actions_.append(self.all_possible_actions[action])

        return all_possible_actions_ 


    def reached_final_state(self):
        state = self.simplify_current_state()
        final_state = (4, 0, 7, 4, 4, 0, 0, 5, 0, 10, 0, 10, 0, 10, 0, 0)  
        return state == final_state


               
        





   
   
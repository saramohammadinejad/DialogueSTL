UP = "up"
DOWN = "down"
LEFT = "left"
RIGHT = "right"
DRY = "at_dry"


#actions
PICK = "pick"
MOVE = "move"
PUT_ON_FLOOR = "put_on_floor"
PASS = "pass"
TURN_ON_FIRE = "turn_on_fire"
TURN_OFF_FIRE = "turn_off_fire"
TURN_ON_LAMP = "turn_on_lamp"
TURN_OFF_LAMP = "turn_off_lamp"
OPEN_THE_DOOR = "open_the_door"
CLOSE_THE_DOOR = "close_the_door"
PLUG_THE_CHARGER = "plug_the_charger"
UNPLUG_THE_CHARGER = "plug_the_charger"
SIT_ON_THE_CHAIR = "sit_on_the_chair"
STAND_UP = "stand_up"


DIRECTIONS = [UP, DOWN, LEFT, RIGHT]


# some colors
BLACK = (0, 0, 0)
BLUE = (135, 206, 235)
WHITE = (255, 255, 255)
GREY = (194, 197, 204)

# This sets the margin between each cell
CELL_MARGIN = 4

# This sets the WIDTH and HEIGHT of each grid location
CELL_WIDTH = 40
CELL_HEIGHT = 40

ROBOT_WIDTH = 32
ROBOT_HEIGHT = 32

# Set the HEIGHT and WIDTH of the screen
WINDOW_SIZE = [800, 600]

ITEM_WIDTH = 32
ITEM_HEIGHT = 32

WALL_CRASH_REWARD = -1000
ROBOT_AT_XY_REWARD = 10
ITEM_AT_XY_REWARD = 15
ITEM_ON_ROBOT_REWARD = 10
CELL_IS_WALL_REWARD = 10
##########################

WIDTH = 12
HEIGHT = 9

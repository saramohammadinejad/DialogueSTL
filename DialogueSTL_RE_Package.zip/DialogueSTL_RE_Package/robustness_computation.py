
import matlab.engine

from utils import distance, min_distance


def robot_at_xy_ro(trace, x=None, y=None):
    ro = []
    for t in range(len(trace.states)):
        robot_pos = trace.states[t].robot_position
        ro.append(-distance(robot_pos, (x,y)))
    return ro
#------------------------------
def item_at_xy_ro(trace, item, x=None, y=None):
    ro = []
    for t in range(len(trace.states)):
        if item in trace.states[t].items_positions:
            item_pos = trace.states[t].items_positions[item]
            ro.append(-distance(item_pos, (x,y)))
        elif item in trace.states[t].items_on_robot:
            item_pos = trace.states[t].robot_position
            # -1 is to cover th case that the robot has reached the 
            # location x,y but has not put the item on the floor
            # in this situation the robustness is -1
            ro.append(-distance(item_pos, (x,y))-1)
        else:
            raise ValueError("Item is lost!!!")
    return ro
#------------------------------
def item_on_robot_ro(trace, item):
    ro = [] 
    for t in range(len(trace.states)):
        if item in trace.states[t].items_on_robot:
            ro.append(1)
        else:
            item_pos = trace.states[t].items_positions[item]
            robot_pos = trace.states[t].robot_position
            dist_to_item = -distance(item_pos, robot_pos)
            ro.append(dist_to_item-1)
    return ro
#------------------------------
def robot_at_wall_ro(trace, grid):
    ro = []
    for t in range(len(trace.states)):
        robot_pos = trace.states[t].robot_position
        ro.append(-min_distance(robot_pos, grid.wall))
    return ro
#------------------------------
def robot_at_water_ro(trace, grid):
    ro = []
    for t in range(len(trace.states)):
        robot_pos = trace.states[t].robot_position
        ro.append(-min_distance(robot_pos, grid.water))
    return ro
#------------------------------
def lamp_on_ro(trace):
    ro = [] 
    for t in range(len(trace.states)):
        dist_to_lamp = distance(trace.states[t].robot_position, trace.states[t].lamp['pos'])
        if trace.states[t].lamp['state']=='on':
            ro.append(1)
        else:
            ro.append(-dist_to_lamp-1)
    return ro
#------------------------------
def lamp_off_ro(trace):
    ro = [] 
    for t in range(len(trace.states)):
        dist_to_lamp = distance(trace.states[t].robot_position, trace.states[t].lamp['pos'])
        if trace.states[t].lamp['state']=='off':
            ro.append(1)
        else:
            ro.append(-1-dist_to_lamp)
    return ro
#------------------------------
def fire_on_ro(trace):
    ro = [] 
    for t in range(len(trace.states)):
        dist_to_fire = distance(trace.states[t].robot_position, trace.states[t].fire['pos'])
        if trace.states[t].fire['state']=='on':
            ro.append(1)
        else:
            ro.append(-1-dist_to_fire)
    return ro
#------------------------------
def fire_off_ro(trace):
    ro = [] 
    for t in range(len(trace.states)):
        dist_to_fire = distance(trace.states[t].robot_position, trace.states[t].fire['pos'])
        if trace.states[t].fire['state']=='off':
            ro.append(1)
        else:
            ro.append(-1-dist_to_fire)
    return ro
#------------------------------
def door_opened_ro(trace):
    ro = [] 
    for t in range(len(trace.states)):
        dist_to_door = distance(trace.states[t].robot_position, trace.states[t].door['pos'])
        if trace.states[t].door['state']=='opened':
            ro.append(1)
        else:
            ro.append(-1-dist_to_door)
    return ro
#------------------------------
def door_closed_ro(trace):
    ro = [] 
    for t in range(len(trace.states)):
        dist_to_door = distance(trace.states[t].robot_position, trace.states[t].door['pos'])
        if trace.states[t].door['state']=='closed':
            ro.append(1)
        else:
            ro.append(-1-dist_to_door)
    return ro
#------------------------------
def charger_plugged_ro(trace):
    ro = [] 
    for t in range(len(trace.states)):
        dist_to_charger = distance(trace.states[t].robot_position, trace.states[t].charger['pos'])
        if trace.states[t].charger['state']=='in_use':
            ro.append(1)
        else:
            ro.append(-1-dist_to_charger)
    return ro
#------------------------------
def charger_unplugged_ro(trace):
    ro = [] 
    for t in range(len(trace.states)):
        dist_to_charger = distance(trace.states[t].robot_position, trace.states[t].charger['pos'])
        if trace.states[t].charger['state']=='not_in_use':
            ro.append(1)
        else:
            ro.append(-1-dist_to_charger)
    return ro
#------------------------------
def robot_is_sitting_on_chair_ro(trace):
    ro = [] 
    for t in range(len(trace.states)):
        dist_to_chair = distance(trace.states[t].robot_position, trace.states[t].chair['pos'])
        if trace.states[t].chair['state']=='robot_sitted_on_chair':
            ro.append(1)
        else:
            ro.append(-1-dist_to_chair)
    return ro
#------------------------------
def robot_is_standing_up_ro(trace):
    ro = [] 
    for t in range(len(trace.states)):
        dist_to_chair = distance(trace.states[t].robot_position, trace.states[t].chair['pos'])
        if trace.states[t].chair['state']=='no_one_sitted_on_chair':
            ro.append(1)
        else:
            ro.append(-1-dist_to_chair)
    return ro
#------------------------------
def compute_atoms_robustness(atoms_param_values, traces, max_trace_len, grid):
    ro = {}
    for atom in atoms_param_values:
        ro[atom]=[]
        traces_len = []
        #max_trace_len = len(traces[0].time_instances)
        for trace in traces:
            trace_len = len(trace.time_instances)
            traces_len.append(trace_len)
            pad = (max_trace_len -trace_len)*[-1000]
            if atom == 'robot_at_xy':
                x = atoms_param_values[atom]['location'][0]
                y = atoms_param_values[atom]['location'][1]
                ro['robot_at_xy'].append(robot_at_xy_ro(trace, x=x, y=y)+pad)
            elif atom == 'item_on_robot':
                item_id = atoms_param_values[atom]['item_id']
                ro['item_on_robot'].append(item_on_robot_ro(trace, item=item_id)+pad)
            elif atom == 'item_at_xy':
                if len(atoms_param_values[atom]['location']) == 0:
                    # default location
                    x = 0
                    y = 0
                else:
                    x = atoms_param_values[atom]['location'][0]
                    y = atoms_param_values[atom]['location'][1]
                item_id = atoms_param_values[atom]['item_id']
                ro['item_at_xy'].append(item_at_xy_ro(trace, item=item_id, x=x, y=y)+pad)
            elif atom == 'lamp_on':
                ro['lamp_on'].append(lamp_on_ro(trace)+pad)
            elif atom == 'lamp_off':
                ro['lamp_off'].append(lamp_off_ro(trace)+pad)
            elif atom == 'fire_on':
                ro['fire_on'].append(fire_on_ro(trace)+pad)
            elif atom == 'fire_off':
                ro['fire_off'].append(fire_off_ro(trace)+pad)
            elif atom == 'door_opened':
                ro['door_opened'].append(door_opened_ro(trace)+pad)
            elif atom == 'door_closed':
                ro['door_closed'].append(door_closed_ro(trace)+pad)
            elif atom == 'robot_is_sitting_on_chair':
                ro['robot_is_sitting_on_chair'].append(robot_is_sitting_on_chair_ro(trace)+pad)
            elif atom == 'charger_plugged':
                ro['charger_plugged'].append(charger_plugged_ro(trace)+pad)
            elif atom == 'charger_unplugged':
                ro['charger_unplugged'].append(charger_unplugged_ro(trace)+pad)
            elif atom == 'robot_at_wall':
                ro['robot_at_wall'].append(robot_at_wall_ro(trace, grid)+pad)
            elif atom == 'robot_at_water':
                ro['robot_at_water'].append(robot_at_water_ro(trace, grid)+pad)
            else:
                raise NotImplementedError

    return ro, traces_len
#------------------------------
def compute_formula_rob(formula, trace_values, traces_len, time_instances=None, eng=None):
    
    if time_instances is None:
       time_instances = list(range(max(traces_len)))


    t = matlab.double(time_instances)
    traces_len = matlab.double(traces_len)
    
    if len(trace_values.keys()) == 1:

        atoms = list(trace_values.keys())
    
        name_0 = atoms[0]
        values_0 = matlab.double(trace_values[name_0])

        # CheckSTLSpec is a matlab script included in the same folder
        rob = eng.CheckSTLSpec_n(formula, 
                                t, 
                                traces_len,
                                name_0, values_0
                                ) 
    elif len(trace_values.keys()) == 2:
        
        atoms = list(trace_values.keys())
    
        name_0 = atoms[0]
        values_0 = matlab.double(trace_values[name_0])

        name_1 = atoms[1]
        values_1 = matlab.double(trace_values[name_1])

        # CheckSTLSpec is a matlab script included in the same folder
        rob = eng.CheckSTLSpec_n(formula, 
                                t,
                                traces_len, 
                                name_0, values_0,
                                name_1, values_1
                                ) 
    elif len(trace_values.keys()) == 3:
    
        atoms = list(trace_values.keys())
    
        name_0 = atoms[0]
        values_0 = matlab.double(trace_values[name_0])

        name_1 = atoms[1]
        values_1 = matlab.double(trace_values[name_1])

        name_2 = atoms[2]
        values_2 = matlab.double(trace_values[name_2])

        # CheckSTLSpec is a matlab script included in the same folder
        rob = eng.CheckSTLSpec_n(formula, 
                                t, 
                                traces_len,
                                name_0, values_0,
                                name_1, values_1,
                                name_2, values_2
                                ) 
    elif len(trace_values.keys()) == 4:

        atoms = list(trace_values.keys())
    
        name_0 = atoms[0]
        values_0 = matlab.double(trace_values[name_0])

        name_1 = atoms[1]
        values_1 = matlab.double(trace_values[name_1])

        name_2 = atoms[2]
        values_2 = matlab.double(trace_values[name_2])

        name_3 = atoms[3]
        values_3 = matlab.double(trace_values[name_3])
    
    
        # CheckSTLSpec is a matlab script included in the same folder
        rob = eng.CheckSTLSpec_n(formula, 
                                t, 
                                traces_len,
                                name_0, values_0,
                                name_1, values_1,
                                name_2, values_2,
                                name_3, values_3,
                                ) 
    else:
        raise NotImplementedError

    return rob






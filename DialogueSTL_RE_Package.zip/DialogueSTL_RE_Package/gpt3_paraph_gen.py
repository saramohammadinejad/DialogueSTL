import openai
from gpt import GPT
from gpt import Example

openai.api_key = 'replace your GPT-3 key'
gpt = GPT(engine="davinci",
          temperature=0.8,
          max_tokens=200)


gpt.add_example(Example("hi", "hello"))
gpt.add_example(Example("How are you?", "How you doing?"))
gpt.add_example(Example("what's up?", "How's it going?"))



sentences = [
'go to location (1,2)',
'walk to location (3,4)',
'put the item at (2,3)',
'place the key at (4,5)',
'pick up the item',
'grab the purple cube',
'take the item from floor',
'go into water',
'walk into wet location',
'hit the wall',
'walk into obstacle',
'turn on the lamp',
'turn the lamp on',
'turn off the lamp',
'turn the lamp off',
'turn on the fire',
'turn off the fire',
'open the door',
'make the door open'
'close the door',
'make the door close',
'plug the charger',
'connect the charger',
'unplug the charger',
'Disconnect the charger',
'sit on the chair',
'get up from the chair',
'robot is at location (1,2)',
'green cube is at (2,3)',
'robot has picked up the item',
'robot is in the water',
'robot is hitting the wall',
'lamp is on',
'lamp is off',
'fire is on',
'fire is off',
'door is open',
'door is closed',
'charger is plugged',
'charger is unplugged',
'robot is sitting on chair',
'robot is standing up']

# generate 20 paraphrases for each sentence
# we only approve the paraphrases with good 
# quality
for sentence in sentences:
    prompt = sentence
    for i in range(20):
        output = gpt.submit_request(prompt)
        paraph = output.choices[0].text
        print(paraph)


import json
import os
import time
from statistics import mean

import matlab.engine
import numpy as np
from flair.models import SequenceTagger
from rasa.core.agent import Agent
from transformers import BertModel, BertTokenizer

from demo import change_world_state, generate_traces
from robustness_computation import (compute_atoms_robustness,
                                    compute_formula_rob)
from semantic_parsing import nl_to_PSTL
from utils import compute_str_accuracy, generate_candidate_stl_formulas
from world import GridWorld

if __name__ == "__main__":

    start_time = time.time()
    str_acc = []
    answers = []

    model = BertModel.from_pretrained('bert-base-uncased', output_hidden_states = True,)
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

       
    #https://huggingface.co/flair/pos-english?text=go+to+location+and+sit+on+the+chair
    #https://github.com/flairNLP/flair/
    # load tagger
    tagger = SequenceTagger.load("flair/pos-english")
    atom_classifier_path = os.getcwd()+'/rasa_atom_classifier/models/nlu-20220830-193425-undecidable-teak.tar.gz'
    atom_classifier = Agent.load(atom_classifier_path)

    
    eng = matlab.engine.start_matlab()

    # loading initial world configuration
    with open(os.getcwd()+'/json_files/world_desc.json') as f:
        world_desc_json = json.load(f)

    # creating the grid world env
    world_obj = GridWorld(world_description=world_desc_json)


    # loading tests json file
    with open(os.getcwd()+'/json_test_files/tests.json') as f:
        tests_json = json.load(f)

    num_tasks = 17
    num_enum_formulas = {}
    for i in range(num_tasks):
        num_enum_formulas['task_'+str(i)] = []
        for j in range(len(tests_json['task_'+str(i)]['nl'])):
            change_world_state(task=i, world_obj=world_obj)
       
            nl = tests_json['task_'+str(i)]['nl'][j]
            print("taskNL:",nl)

            # converting NL to PST formulas
            formulas, lower_bound, upper_bound, atoms_param_values, time_params_value, best_atoms, best_operators, task_type, after_if_atom = nl_to_PSTL(nl, model, tokenizer, atom_classifier, tagger, tests_json['task_'+str(i)]['interactions'])
            print("\nExplanation dictionaries:", best_atoms, best_operators)
        
            # convert PSTL to STL
            stl_formulas = generate_candidate_stl_formulas(formulas, lower_bound, upper_bound, atoms_param_values, time_params_value)
            num_enum_formulas['task_'+str(i)].append(len(stl_formulas))

            # generate traces
            all_traces, n_traces, max_len_traces = generate_traces(task_type, world_obj, tests_json['task_'+str(i)]['demos'], task=i)
            

            # compute atoms robustnesses
            ro, traces_len = compute_atoms_robustness(atoms_param_values,  all_traces, max_len_traces, world_obj)


            # compute stl formulas' robustness
            finall_rob = compute_formula_rob(stl_formulas, ro, traces_len, eng=eng)
    
            # detect formulas with positive robustness for positive 
            # trace and negative robustness for the negative traces
        
            num_traces_each_f = traces_len[0]-1
            correct_stl_found = False
            incorrect_stl_result = None
            for k in range(len(stl_formulas)):

                rob_formula = list(finall_rob[0])[k*n_traces:(k+1)*n_traces]
                if task_type == ['multiple_choice'] and rob_formula[0] >= 0 and rob_formula[1] >= 0 and all([rob_formula[j] < 0 for j in range(2, len(rob_formula))]):

                    if stl_formulas[k] in tests_json['task_'+str(i)]['target-stl-formula']:
                        correct_stl_found = True
                    else:
                        incorrect_stl_result = stl_formulas[k]
                    break
                elif task_type != ['multiple_choice'] and rob_formula[0] >= 0 and all([rob_formula[m] < 0 for m in range(1, len(rob_formula))]):
                    if stl_formulas[k] in tests_json['task_'+str(i)]['target-stl-formula']:
                        correct_stl_found = True
                    else:
                        incorrect_stl_result = stl_formulas[k]
                    break
                        

            if correct_stl_found:
                answers.append("correct")
                print(f"\nFound correct STL formula for task {i}:", stl_formulas[k])
                str_acc.append(1.0)
            else:
                answers.append("incorrect")
                print(f"\nCould not find correct STL formula for task {i}")
                if incorrect_stl_result:
                    str_acc.append(compute_str_accuracy(tests_json['task_'+str(i)]['target-stl-formula'][0],incorrect_stl_result))
                else:
                    str_acc.append(0)

            print("--------------------------------------------------------")
    print("Avg success rate is:", answers.count("correct")/len(answers))
    print("Answers:", answers)
    print("Avg accuracy is:", mean(str_acc))
    print("Avg test runtime:", (time.time()-start_time)/len(answers))
    print("Number of enumerated formulas:", num_enum_formulas)
    


    







    